import re
import pandas
import requests

session = requests.session()
home_url='https://www.fielmann.de/'
r=requests.get(home_url)

with open("home.json","wb") as f:
    f.write(r.content)

product_details=re.findall(r'lg\s+textColorClasses"><!----> <span class="content pointer-events-none">\s*(.*?)\s*\<',str(r.content),re.S)
new_products=[]
for i in product_details:
    new_products.append(i.replace("\\n","").replace(" ","").replace("\\xc3\\xb6",'o'))
new_url=home_url+new_products[0].lower()
df1=pandas.DataFrame(new_products)
df1.to_csv("products.csv")
r1=session.get(new_url)
print(new_url)
print(r1)

glass_details=re.findall(r'leading-tight text-base font-medium uppercase">(.*?)\s*\<',str(r1.content),re.S)

new_glass_products=[]
new_glass=[]
for i in glass_details:
    new_glass.append(i.replace("\\n","").replace("\\xc3\\xa9",'e').replace(" ","-").replace("--","").lower())
df1=pandas.DataFrame(new_glass_products)
df1.to_csv("glass_products.csv")
for item in new_glass:
    if item not in new_glass_products:
        new_glass_products.append(item)  
new=[]
for i in range(0,len(new_glass_products)):
    url=new_glass_products[i]
    glass_specs=re.findall(f'<a href="\/p\/{url}\s*(.*?)\/',str(r1.content),re.S)
    spec_url=home_url+'p/'+new_glass_products[i]+glass_specs[0]
    r2=session.get(spec_url)
    product_name=re.findall(r'uppercase">(.*?)\<',str(r2.content),re.S)
    product_price=re.findall(r'"text-2xl">(.*?)\<',str(r2.content),re.S)
    dict={}
    dict['product name']=product_name[0].replace("\\xc3\\xa9","e")
    dict['product price']=product_price[0].replace('\\xc2\\xa0\\xe2\\x82\\xac',"")
    new.append(dict)
print(new)
df=pandas.DataFrame(new)
df.to_csv("new.csv")