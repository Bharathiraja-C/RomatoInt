// CreateUser.jsx
import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import UserService from '../Services/UserService'; // Import the UserService

const CreateUser = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await UserService.createUser(email, password);
            console.log('User created successfully:', result);
            // Handle success (e.g., show a success message)
        } catch (error) {
            console.error('Error creating user:', error);
            // Handle error (e.g., display an error message)
        }
    };

    return (
        <div className="form-head">
            <center className="create-user-head">Create New User</center>
            <br />
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>
                <br />

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Temporary Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="Temporary Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </Form.Group>
                <br />
                <Form.Group controlId="formBasicPassword">
                    <Form.Label>New Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="New Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </Form.Group>

                <br />
                <Button className="Button" type="submit">Update</Button>
            </Form>
        </div>
    );
};

export default CreateUser;
