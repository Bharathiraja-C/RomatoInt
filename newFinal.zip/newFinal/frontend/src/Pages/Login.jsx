import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import './Login.css';
import AuthService from '../Services/AuthService';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate(); // Hook for navigation

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await AuthService.login(email, password);
            console.log('Login successful:', result);
            // Redirect to user creation page after successful login
            navigate('/create-user');
        } catch (error) {
            console.error('Login failed:', error);
            // Handle login error (e.g., display error message to user)
        }
    };

    return (
        <div className="form-head">
            <center className="login-head">Login</center>
            <br />
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email Id</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>
                <br />

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </Form.Group>
                
                <br />
                <Button className="Button" type="submit">Log In</Button>
            </Form>
        </div>
    );
};

export default Login;
