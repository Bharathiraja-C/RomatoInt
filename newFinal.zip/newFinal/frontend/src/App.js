import logo from './logo.svg';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css';
import Login from './Pages/Login';
import UserCreation from './Pages/UserCreation';
import UpdatePassword from './Pages/UpdatePassword';
function App() {
  return (
    
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login/>} />
        <Route path='/create-user' element={<UserCreation/>} />
        <Route path='/update-password' element={<UpdatePassword/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
