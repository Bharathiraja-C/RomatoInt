// services/AuthService.js
import axios from 'axios';

const AuthService = {
    async login(email, password) {
        try {
            const response = await axios.post('http://localhost:5000/api/login', { email, password });
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    }
};

export default AuthService;
