const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

pool.connect()
  .then(() => console.log('Connected to PostgreSQL database'))
  .catch(err => console.error('Error connecting to PostgreSQL database:', err));

const UserModel = {
    async createUser(email, Password ,role) {
        try {
          const query = {
            text: 'INSERT INTO users (username, password,role) VALUES ($1, $2, $3)',
            values: [email, Password,role],
          };
    
          await pool.query(query);
        } catch (error) {
          throw error;
        }
      },
    async findUserByEmailAndPassword(email, password) {
        const query = {
            text: 'SELECT * FROM users WHERE username = $1 AND password = $2',
            values: [email, password],
        };

        try {
            const result = await pool.query(query);
            return result.rows[0];
        } catch (error) {
            throw error;
        }
    }
};

module.exports = UserModel;
