// controllers/UserController.js
const bcrypt = require('bcrypt');
const UserModel = require('../models/UserModel');
const sendEmail = require('../utils/mailer');

const UserController = {
  async createUser(req, res) {
    const { email,role } = req.body;

    try {
      // Generate temporary password
      const tempPassword = Math.random().toString(36).slice(-8); // Generate a random string
    

      // Create user in database with temporary password
      await UserModel.createUser(email, tempPassword,role);

      // Send email to user with temporary username and password
      // const text = `
      //   Dear User,

      //   Your temporary username is: ${email}
      //   Your temporary password is: ${tempPassword}

      //   Please click on the link to update your password: http://localhost:3000/update-password

      //   Best regards,
      //   Your Website Team
      // `;

      // await sendEmail(email, text);

      res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
};

module.exports = UserController;
