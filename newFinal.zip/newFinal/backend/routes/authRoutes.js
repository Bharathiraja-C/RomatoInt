// authRoutes.js
const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/AuthController');
const UserController = require('../controllers/UserController');


// Route for handling login
router.post('/login', AuthController.login);

// Route for creating a new user
router.post('/create-user', UserController.createUser);

module.exports = router;
